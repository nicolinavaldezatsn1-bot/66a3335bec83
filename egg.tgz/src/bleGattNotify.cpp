// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Push GATT notification\n", stdout);
  return lionss_run_workload("bleGattNotify");
}
