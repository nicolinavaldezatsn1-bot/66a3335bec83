// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Evict KV entries"); }
int main(){
  announce();
  return lionss_run_workload("kvcache_evict");
}
