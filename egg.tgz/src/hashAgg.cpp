// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Hash-aggregate groups"); }
int main(){
  announce();
  return lionss_run_workload("hashAgg");
}
