// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Observe resource\n", stdout);
  return lionss_run_workload("coap-observe");
}
