// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Simulate CUBIC growth"); }
int main(){
  announce();
  return lionss_run_workload("TcpCubic");
}
